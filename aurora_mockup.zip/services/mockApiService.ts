import { SaleStatus, PresaleData, UserData } from '../types';

// --- Mock Database ---
let mockPresaleData: PresaleData = {
    tokenName: 'Aurora',
    tokenSymbol: 'AUR',
    status: SaleStatus.LIVE,
    tokensSold: 65_000_000,
    totalTokens: 100_000_000,
    tokenPrice: 0.005, // ETH
    saleEndTime: new Date(Date.now() + 1000 * 60 * 60 * 24 * 3), // 3 days from now
    minPurchase: 0.1,
    maxPurchase: 5
};

const mockUserDatabase: { [address: string]: UserData } = {};
// ---------------------

const SIMULATED_DELAY = 800; // ms

export const fetchPresaleData = (): Promise<PresaleData> => {
    return new Promise(resolve => {
        setTimeout(() => {
            // Simulate sale ending
            if (mockPresaleData.saleEndTime.getTime() < Date.now()) {
                mockPresaleData.status = SaleStatus.ENDED;
            }
            resolve({ ...mockPresaleData });
        }, SIMULATED_DELAY);
    });
};

export const connectWallet = (): Promise<string> => {
    return new Promise(resolve => {
        setTimeout(() => {
            const mockAddress = `0x${[...Array(40)].map(() => Math.floor(Math.random() * 16).toString(16)).join('')}`;
            resolve(mockAddress);
        }, SIMULATED_DELAY / 2);
    });
};

export const fetchUserData = (address: string): Promise<UserData> => {
    return new Promise(resolve => {
        setTimeout(() => {
            if (!mockUserDatabase[address]) {
                mockUserDatabase[address] = {
                    address: address,
                    isWhitelisted: Math.random() > 0.2, // 80% chance to be whitelisted
                    contribution: 0,
                    tokensOwed: 0,
                };
            }
            resolve({ ...mockUserDatabase[address] });
        }, SIMULATED_DELAY);
    });
};

export const buyTokens = (address: string, amount: number): Promise<{ success: boolean }> => {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            const user = mockUserDatabase[address];
            if (!user) {
                return reject(new Error("Usuário não encontrado. Conecte a carteira primeiro."));
            }
            if (!user.isWhitelisted) {
                return reject(new Error("Seu endereço não está na whitelist para esta pré-venda."));
            }
            if (mockPresaleData.status !== SaleStatus.LIVE) {
                return reject(new Error("A pré-venda não está ativa."));
            }
            if (amount < mockPresaleData.minPurchase) {
                return reject(new Error(`A compra mínima é de ${mockPresaleData.minPurchase} ETH.`));
            }
            if ((user.contribution + amount) > mockPresaleData.maxPurchase) {
                 return reject(new Error(`Sua contribuição total não pode exceder ${mockPresaleData.maxPurchase} ETH.`));
            }
            
            const tokensBought = amount / mockPresaleData.tokenPrice;
            if ((mockPresaleData.tokensSold + tokensBought) > mockPresaleData.totalTokens) {
                 return reject(new Error("Não há tokens suficientes para completar esta compra."));
            }

            // Update state on success
            user.contribution += amount;
            user.tokensOwed += tokensBought;
            mockPresaleData.tokensSold += tokensBought;

            resolve({ success: true });

        }, SIMULATED_DELAY * 2);
    });
};